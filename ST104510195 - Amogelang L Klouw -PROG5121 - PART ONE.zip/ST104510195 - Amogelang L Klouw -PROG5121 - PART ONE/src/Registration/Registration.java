package Registration;

import java.util.Scanner;

public class Registration {
    //access specifiers
    private static String firstName;
    private static String surname;
    private static String userName;
    private static String password;
   
    //get and set methods - all variables are (get and set) individually
     public static void setFirstName(String name) {
         firstName = name;
     }
     public static String getFirstName() {
         return firstName;
     }
      public static void setSurname(String name) {
         surname = name;
     }
     public static String getSurname() {
         return surname;
     }
      public static void setUserName(String username) {
         userName = username;
     }
     public static String getUserName() {
         return userName;
     }
     public static void setPassword(String pass) {
         password = pass;
     }
     public static String getPassword() {
         return password;
     }
     
    
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        Login logObj = new Login(); //links to login page
        //attaining user details
        System.out.println("REGISTRATION:");
        System.out.println(); 
        System.out.println("Enter your first name");
        setFirstName(input.nextLine()); //for the code to get to the next line when you enter whats asked for
        System.out.println("Enter your surname");
        setSurname(input.nextLine());
        System.out.println("Enter your username. Note: Username must be 5 characters or less and contain an underscore.");
        setUserName(input.nextLine());
        
        logObj.checkUserName(getUserName());
        
        System.out.println("Enter your password");
        setPassword(input.nextLine());
        
        logObj.checkPasswordComplexity(getPassword());
        
        System.out.println(logObj.registerUser(getUserName(), getPassword() ));
        
        boolean regStatus = logObj.LoginUser(logObj.checkUserName(getUserName()), logObj.checkPasswordComplexity(getPassword() ));
        
        System.out.println(logObj.returnLoginStatus(regStatus,getFirstName(),getSurname() ));
        
    }
    
}
