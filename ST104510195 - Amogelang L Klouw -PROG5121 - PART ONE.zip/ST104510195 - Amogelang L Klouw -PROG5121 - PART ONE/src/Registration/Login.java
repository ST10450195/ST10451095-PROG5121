
package Registration;
import java.util.Scanner;


public class Login {
    Registration regObject = new Registration();
    String passMessage = "Password is not correctly formatted. Please ensure that the password contains at least 8 characters, a capital letter, a number and a special character.";
    String nameMessage = "Username is not correctly formatted. Please ensure that the username contains an underscore and is no more than 5 characters in length.";
    
   public boolean checkUserName(String userName){
       if (userName.length() <= 5 && userName.contains("_")){
           return true;
       }
       return false;
   }
    
    public boolean checkPasswordComplexity(String password) {
        //Declarations of variables
        boolean passwordOkay = false;
        boolean hasNumber = false;
        boolean hasCap = false;
        boolean hasChar = false;
        char current = 0;//current thing works on an individual character
        
        if (password.length()>=8){
            for (int i = 0; i < password.length();i++){
                current = password.charAt(i);   
        if (Character.isUpperCase(current)){
            hasCap = true;
        }
        if (Character.isDigit(current)){
            hasNumber = true;
            }
        if (!Character.isLetterOrDigit(current)){//if it is not a letter or digit 
            hasChar = true;
        }
        if (hasNumber&&hasCap && hasChar){
            passwordOkay = true;
        }
            }
        }
        return passwordOkay;
        
    }

    public String registerUser(String username, String password){ 
     if (checkPasswordComplexity(password)){
        passMessage = "Password successfully captured";
        }
     if (checkUserName(username)){
        nameMessage = "Username successfully captured";
        }
        return (passMessage + "\n" + nameMessage);
    }
    
    public boolean LoginUser(boolean checkUserName, boolean checkPassword){
        boolean logged = false;
    
     if(checkUserName && checkPassword){ 
        Scanner input = new Scanner(System.in);//Scanner accepts input from the user
        
        System.out.println("LOGIN");
        System.out.println("Please enter the username you provided earlier:");
        String username = input.nextLine();
        System.out.println("Please enter the password you entered earlier:");
        String password = input.nextLine();
        
        if (password.equals(Registration.getPassword()) && username.equals(Registration.getUserName()) ){
            logged = true;
        }
    }
     return logged;
    }
   public String returnLoginStatus(boolean regStatus, String name, String surname){
       String message = "Username or password incorrect, please try again";
       
       if(regStatus){
           message = "Welcome " + name + " " + surname + "," + " It is great to see you!";
       }
       return message;
   }
}